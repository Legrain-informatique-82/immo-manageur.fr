Hi,

Feel free to send me an email at jbdemonte@gmail.com

To contribute to gmap3, you can :

- report bugs or comments
- help me to add new features
- make gmap3 to be known
- add a link to gmap3.net on your website
- donate on gmap3.net

Thanks for using gmap3.

JB.