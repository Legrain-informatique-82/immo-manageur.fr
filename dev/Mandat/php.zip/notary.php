<?php

/**
 * @class Notary
 * @date 10/02/2011 (dd/mm/yyyy)
 * @generator WebProjectHelper (http://www.elfangels.fr/webprojecthelper/)
 */
class Notary
{
	/// @var PDO 
	private $pdo;
	
	/// @var array tableau pour le chargement rapide
	private static $easyload;
	
	/// @var int 
	private $idNotary;
	
	/// @var int 
	private $n;
	
	/**
	 * Construire un(e) notary
	 * @param $pdo PDO 
	 * @param $idNotary int 
	 * @param $n int 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Notary 
	 */
	protected function __construct(PDO $pdo,$idNotary,$n,$easyload=false)
	{
		// Sauvegarder pdo
		$this->pdo = $pdo;
		
		// Sauvegarder les attributs
		$this->idNotary = $idNotary;
		$this->n = $n;
		
		// Sauvegarder pour le chargement rapide
		if ($easyload) {
			Notary::$easyload[$idNotary] = $this;
		}
	}
	
	/**
	 * Cr�er un(e) notary
	 * @param $pdo PDO 
	 * @param $n int 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Notary 
	 */
	public static function create(PDO $pdo,$n,$easyload=true)
	{
		// Ajouter le/la notary dans la base de donn�es
		$pdoStatement = $pdo->prepare('INSERT INTO Notary (n) VALUES (?)');
		if (!$pdoStatement->execute(array($n))) {
			throw new Exception('Erreur durant l\'insertion d\'un(e) notary dans la base de donn�es');
		}
		
		// Construire le/la notary
		return new Notary($pdo,$pdo->lastInsertId(),$n,$easyload);
	}
	
	/**
	 * Requ�te de s�l�ction
	 * @param $pdo PDO 
	 * @param $where string 
	 * @param $orderby string 
	 * @param $limit string 
	 * @return PDOStatement 
	 */
	private static function _select(PDO $pdo,$where=null,$orderby=null,$limit=null)
	{
		return $pdo->prepare('SELECT n.idNotary, n.n FROM Notary n '.
		                     ($where != null ? ' WHERE '.$where : '').
		                     ($orderby != null ? ' ORDERBY '.$orderby : '').
		                     ($limit != null ? ' LIMIT '.$limit : ''));
	}
	
	/**
	 * Charger un(e) notary
	 * @param $pdo PDO 
	 * @param $idNotary int 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Notary 
	 */
	public static function load(PDO $pdo,$idNotary,$easyload=true)
	{
		// D�j� charg�(e) ?
		if (isset(Notary::$easyload[$idNotary])) {
			return Notary::$easyload[$idNotary];
		}
		
		// Charger le/la notary
		$pdoStatement = Notary::_select($pdo,'n.idNotary = ?');
		if (!$pdoStatement->execute(array($idNotary))) {
			throw new Exception('Erreur lors du chargement d\'un(e) notary depuis la base de donn�es');
		}
		
		// R�cup�rer le/la notary depuis le jeu de r�sultats
		return Notary::fetch($pdo,$pdoStatement,$easyload);
	}
	
	/**
	 * Charger tous/toutes les notarys
	 * @param $pdo PDO 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Notary[] tableau de notarys
	 */
	public static function loadAll(PDO $pdo,$easyload=false)
	{
		// S�lectionner tous/toutes les notarys
		$pdoStatement = Notary::selectAll($pdo);
		
		// Mettre chaque notary dans un tableau
		$notarys = array();
		while ($notary = Notary::fetch($pdo,$pdoStatement,$easyload)) {
			$notarys[] = $notary;
		}
		
		// Retourner le tableau
		return $notarys;
	}
	
	/**
	 * S�lectionner tous/toutes les notarys
	 * @param $pdo PDO 
	 * @return PDOStatement 
	 */
	public static function selectAll(PDO $pdo)
	{
		$pdoStatement = Notary::_select($pdo);
		if (!$pdoStatement->execute()) {
			throw new Exception('Erreur lors du chargement de tous/toutes les notarys depuis la base de donn�es');
		}
		return $pdoStatement;
	}
	
	/**
	 * R�cup�re le/la notary suivant(e) d'un jeu de r�sultats
	 * @param $pdo PDO 
	 * @param $pdoStatement PDOStatement 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Notary 
	 */
	public static function fetch(PDO $pdo,PDOStatement $pdoStatement,$easyload=false)
	{
		// Extraire les valeurs
		$values = $pdoStatement->fetch();
		if (!$values) { return null; }
		list($idNotary,$n) = $values;
		
		// Construire le/la notary
		return isset(Notary::$easyload[$idNotary.'-'.$n]) ? Notary::$easyload[$idNotary.'-'.$n] :
		                                                    new Notary($pdo,$idNotary,$n,$easyload);
	}
	
	/**
	 * Supprimer le/la notary
	 * @return bool op�ration r�ussie ?
	 */
	public function delete()
	{
		// Supprimer les mandates associ�(e)s
		$select = $this->selectMandates();
		while ($mandate = Mandate::fetch($this->pdo,$select)) {
			if (!$mandate->delete()) { return false; }
		}
		
		// Supprimer le/la notary
		$pdoStatement = $this->pdo->prepare('DELETE FROM Notary WHERE idNotary = ?');
		if (!$pdoStatement->execute(array($this->getIdNotary()))) {
			throw new Exception('Erreur lors de la supression d\'un(e) notary dans la base de donn�es');
		}
		
		// Op�ration r�ussie ?
		return $pdoStatement->rowCount() == 1;
	}
	
	/**
	 * Mettre � jour un champ dans la base de donn�es
	 * @param $fields array 
	 * @param $values array 
	 * @return bool op�ration r�ussie ?
	 */
	private function _set($fields,$values)
	{
		// Pr�parer la mise � jour
		$updates = array();
		foreach ($fields as $field) {
			$updates[] = $field.' = ?';
		}
		
		// Mettre � jour le champ
		$pdoStatement = $this->pdo->prepare('UPDATE Notary SET '.implode(', ', $updates).' WHERE idNotary = ?');
		if (!$pdoStatement->execute(array_merge($values,array($this->getIdNotary())))) {
			throw new Exception('Erreur lors de la mise � jour d\'un champ d\'un(e) notary dans la base de donn�es');
		}
		
		// Op�ration r�ussie ?
		return $pdoStatement->rowCount() == 1;
	}
	
	/**
	 * Mettre � jour tous les champs dans la base de donn�es
	 * @return bool op�ration r�ussie ?
	 */
	public function update()
	{
		return $this->_set(array('n'),array($this->n));
	}
	
	/**
	 * R�cup�rer le/la idNotary
	 * @return int 
	 */
	public function getIdNotary()
	{
		return $this->idNotary;
	}
	
	/**
	 * R�cup�rer le/la n
	 * @return int 
	 */
	public function getN()
	{
		return $this->n;
	}
	
	/**
	 * D�finir le/la n
	 * @param $n int 
	 * @param $execute bool ex�cuter la requ�te update ?
	 * @return bool op�ration r�ussie ?
	 */
	public function setN($n,$execute=true)
	{
		// Sauvegarder dans l'objet
		$this->n = $n;
		
		// Sauvegarder dans la base de donn�es (ou pas)
		return $execute ? $this->_set(array('n'),array($n)) : true;
	}
	
	/**
	 * S�lectionner les mandates
	 * @return PDOStatement 
	 */
	public function selectMandates()
	{
		return Mandate::selectByNotary($this->pdo,$this);
	}
}

?>
