<?php

/**
 * @class Seller
 * @date 10/02/2011 (dd/mm/yyyy)
 * @generator WebProjectHelper (http://www.elfangels.fr/webprojecthelper/)
 */
class Seller
{
	/// @var PDO 
	private $pdo;
	
	/// @var array tableau pour le chargement rapide
	private static $easyload;
	
	/// @var int 
	private $idSeller;
	
	/// @var int 
	private $n;
	
	/// @var int id de mandate
	private $mandate;
	
	/**
	 * Construire un(e) seller
	 * @param $pdo PDO 
	 * @param $idSeller int 
	 * @param $n int 
	 * @param $mandate int id de mandate
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Seller 
	 */
	protected function __construct(PDO $pdo,$idSeller,$n,$mandate=null,$easyload=false)
	{
		// Sauvegarder pdo
		$this->pdo = $pdo;
		
		// Sauvegarder les attributs
		$this->idSeller = $idSeller;
		$this->n = $n;
		$this->mandate = $mandate;
		
		// Sauvegarder pour le chargement rapide
		if ($easyload) {
			Seller::$easyload[$idSeller] = $this;
		}
	}
	
	/**
	 * Cr�er un(e) seller
	 * @param $pdo PDO 
	 * @param $n int 
	 * @param $mandate Mandate 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Seller 
	 */
	public static function create(PDO $pdo,$n,$mandate=null,$easyload=true)
	{
		// Ajouter le/la seller dans la base de donn�es
		$pdoStatement = $pdo->prepare('INSERT INTO Seller (n,fk_idMandate) VALUES (?,?)');
		if (!$pdoStatement->execute(array($n,$mandate == null ? null : $mandate->getIdMandate()))) {
			throw new Exception('Erreur durant l\'insertion d\'un(e) seller dans la base de donn�es');
		}
		
		// Construire le/la seller
		return new Seller($pdo,$pdo->lastInsertId(),$n,$mandate->getIdMandate(),$easyload);
	}
	
	/**
	 * Requ�te de s�l�ction
	 * @param $pdo PDO 
	 * @param $where string 
	 * @param $orderby string 
	 * @param $limit string 
	 * @return PDOStatement 
	 */
	private static function _select(PDO $pdo,$where=null,$orderby=null,$limit=null)
	{
		return $pdo->prepare('SELECT s.idSeller, s.n, s.fk_idMandate FROM Seller s '.
		                     ($where != null ? ' WHERE '.$where : '').
		                     ($orderby != null ? ' ORDERBY '.$orderby : '').
		                     ($limit != null ? ' LIMIT '.$limit : ''));
	}
	
	/**
	 * Charger un(e) seller
	 * @param $pdo PDO 
	 * @param $idSeller int 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Seller 
	 */
	public static function load(PDO $pdo,$idSeller,$easyload=true)
	{
		// D�j� charg�(e) ?
		if (isset(Seller::$easyload[$idSeller])) {
			return Seller::$easyload[$idSeller];
		}
		
		// Charger le/la seller
		$pdoStatement = Seller::_select($pdo,'s.idSeller = ?');
		if (!$pdoStatement->execute(array($idSeller))) {
			throw new Exception('Erreur lors du chargement d\'un(e) seller depuis la base de donn�es');
		}
		
		// R�cup�rer le/la seller depuis le jeu de r�sultats
		return Seller::fetch($pdo,$pdoStatement,$easyload);
	}
	
	/**
	 * Charger tous/toutes les sellers
	 * @param $pdo PDO 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Seller[] tableau de sellers
	 */
	public static function loadAll(PDO $pdo,$easyload=false)
	{
		// S�lectionner tous/toutes les sellers
		$pdoStatement = Seller::selectAll($pdo);
		
		// Mettre chaque seller dans un tableau
		$sellers = array();
		while ($seller = Seller::fetch($pdo,$pdoStatement,$easyload)) {
			$sellers[] = $seller;
		}
		
		// Retourner le tableau
		return $sellers;
	}
	
	/**
	 * S�lectionner tous/toutes les sellers
	 * @param $pdo PDO 
	 * @return PDOStatement 
	 */
	public static function selectAll(PDO $pdo)
	{
		$pdoStatement = Seller::_select($pdo);
		if (!$pdoStatement->execute()) {
			throw new Exception('Erreur lors du chargement de tous/toutes les sellers depuis la base de donn�es');
		}
		return $pdoStatement;
	}
	
	/**
	 * R�cup�re le/la seller suivant(e) d'un jeu de r�sultats
	 * @param $pdo PDO 
	 * @param $pdoStatement PDOStatement 
	 * @param $easyload bool activer le chargement rapide ?
	 * @return Seller 
	 */
	public static function fetch(PDO $pdo,PDOStatement $pdoStatement,$easyload=false)
	{
		// Extraire les valeurs
		$values = $pdoStatement->fetch();
		if (!$values) { return null; }
		list($idSeller,$n,$mandate) = $values;
		
		// Construire le/la seller
		return isset(Seller::$easyload[$idSeller.'-'.$n.'-'.$mandate]) ? Seller::$easyload[$idSeller.'-'.$n.'-'.$mandate] :
		                                                                 new Seller($pdo,$idSeller,$n,$mandate,$easyload);
	}
	
	/**
	 * Supprimer le/la seller
	 * @return bool op�ration r�ussie ?
	 */
	public function delete()
	{
		// Supprimer le/la seller
		$pdoStatement = $this->pdo->prepare('DELETE FROM Seller WHERE idSeller = ?');
		if (!$pdoStatement->execute(array($this->getIdSeller()))) {
			throw new Exception('Erreur lors de la supression d\'un(e) seller dans la base de donn�es');
		}
		
		// Op�ration r�ussie ?
		return $pdoStatement->rowCount() == 1;
	}
	
	/**
	 * Mettre � jour un champ dans la base de donn�es
	 * @param $fields array 
	 * @param $values array 
	 * @return bool op�ration r�ussie ?
	 */
	private function _set($fields,$values)
	{
		// Pr�parer la mise � jour
		$updates = array();
		foreach ($fields as $field) {
			$updates[] = $field.' = ?';
		}
		
		// Mettre � jour le champ
		$pdoStatement = $this->pdo->prepare('UPDATE Seller SET '.implode(', ', $updates).' WHERE idSeller = ?');
		if (!$pdoStatement->execute(array_merge($values,array($this->getIdSeller())))) {
			throw new Exception('Erreur lors de la mise � jour d\'un champ d\'un(e) seller dans la base de donn�es');
		}
		
		// Op�ration r�ussie ?
		return $pdoStatement->rowCount() == 1;
	}
	
	/**
	 * Mettre � jour tous les champs dans la base de donn�es
	 * @return bool op�ration r�ussie ?
	 */
	public function update()
	{
		return $this->_set(array('n','fk_idMandate'),array($this->n,$this->mandate));
	}
	
	/**
	 * R�cup�rer le/la idSeller
	 * @return int 
	 */
	public function getIdSeller()
	{
		return $this->idSeller;
	}
	
	/**
	 * R�cup�rer le/la n
	 * @return int 
	 */
	public function getN()
	{
		return $this->n;
	}
	
	/**
	 * D�finir le/la n
	 * @param $n int 
	 * @param $execute bool ex�cuter la requ�te update ?
	 * @return bool op�ration r�ussie ?
	 */
	public function setN($n,$execute=true)
	{
		// Sauvegarder dans l'objet
		$this->n = $n;
		
		// Sauvegarder dans la base de donn�es (ou pas)
		return $execute ? $this->_set(array('n'),array($n)) : true;
	}
	
	/**
	 * R�cup�rer le/la mandate
	 * @return Mandate 
	 */
	public function getMandate()
	{
		// Retourner null si n�c�ssaire
		if ($this->mandate == null) { return null; }
		
		// Charger et retourner mandate
		return Mandate::load($this->pdo,$this->mandate);
	}
	
	/**
	 * D�finir le/la mandate
	 * @param $mandate Mandate 
	 * @param $execute bool ex�cuter la requ�te update ?
	 * @return bool op�ration r�ussie ?
	 */
	public function setMandate($mandate=null,$execute=true)
	{
		// Sauvegarder dans l'objet
		$this->mandate = $mandate == null ? null : $mandate->getIdMandate();
		
		// Sauvegarder dans la base de donn�es (ou pas)
		return $execute ? $this->_set(array('fk_idMandate'),array($mandate == null ? null : $mandate->getIdMandate())) : true;
	}
	
	/**
	 * S�lectionner les sellers par mandate
	 * @param $pdo PDO 
	 * @param $mandate Mandate 
	 * @return PDOStatement 
	 */
	public static function selectByMandate(PDO $pdo,Mandate $mandate)
	{
		$pdoStatement = $pdo->prepare('SELECT s.idSeller, s.n, s.fk_idMandate FROM Seller s WHERE s.fk_idMandate = ?');
		if (!$pdoStatement->execute(array($mandate->getIdMandate()))) {
			throw new Exception('Erreur lors du chargement de tous/toutes les sellers par mandate depuis la base de donn�es');
		}
		return $pdoStatement;
	}
}

?>
