<?php

// Chargement des classes PHP
require('user.php');
require('sector.php');
require('city.php');
require('notary.php');
require('mandatetype.php');
require('transactiontype.php');
require('seller.php');
require('mandatepicture.php');
require('mandateslope.php');
require('mandatescan.php');
require('mandateorientation.php');
require('mandateinsulation.php');
require('mandatenews.php');
require('mandateheating.php');
require('mandatecommonownership.php');
require('mandateroof.php');
require('mandatecondition.php');
require('mandatestyle.php');
require('mandateconstructiontype.php');
require('mandatesanitationcorresponding.php');
require('mandateelectriccorresponding.php');
require('mandategazcorresponding.php');
require('mandatewatercorresponding.php');
require('mandatecos.php');
require('mandatezonageplu.php');
require('mandatezonagernu.php');
require('mandatebornageterrain.php');
require('mandategeometer.php');
require('mandateetap.php');
require('mandate.php');

?>
