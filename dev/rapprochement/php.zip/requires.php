<?php

// Chargement des classes PHP
require('user.php');
require('acquereur.php');
require('mandate.php');
require('rapprochement.php');

?>
