<?php

// Chargement des classes PHP
require('city.php');
require('transactiontype.php');
require('mandatestyle.php');
require('sector.php');
require('titreacquereur.php');
require('acquereur.php');

?>
