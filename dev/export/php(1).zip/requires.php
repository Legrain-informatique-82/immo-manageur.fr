<?php

// Chargement des classes PHP
require('mandate.php');
require('passerelle.php');
require('liasonpasserellemandat.php');
require('logtransfert.php');

?>
