<?php 

class Module_Controller_testz implements interfaceController{
	private $_smarty;
	public function __construct($smarty){
		$this->_smarty = $smarty;
	}
	public function addMeta($array = 'module test  dans user test Z'){
		return $array;
	}
	public function displayTpl( ){}
	public function treatment( $array){}
}

$module = new Module_Controller_testz( $this->_smarty );

?>
