<?php

// Chargement des classes PHP
require('transactiontype.php');
require('mandatetype.php');

?>
